***************************************************************
* Arduino PID Library - Version 1.1.0
 
* by Brett Beauregard <br3ttb@gmail.com> brettbeauregard.com
 
*
 
* This Library is licensed under a GPLv3 License

***************************************************************

 - To Use, copy the PID_v1 folder into the Arduino\Libraries directory

 - For an ultra-detailed explanation of why the code is the way it is, please visit: 
   http://brettbeauregard.com/blog/2011/04/improving-the-beginners-pid-introduction/